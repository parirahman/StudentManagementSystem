package termproject;

public interface IExtraFeeCalculator {
	public abstract int getExtraAmount(int coursetotal);

}
