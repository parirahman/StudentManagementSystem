package termproject;

public class BDTaxCalculator{
	public double calculateVatAmount(int total) {
		double bdtax= total*0.15;
		return bdtax;
	}

}
